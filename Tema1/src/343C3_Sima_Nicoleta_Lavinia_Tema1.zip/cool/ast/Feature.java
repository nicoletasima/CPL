package cool.ast;

public abstract class Feature extends ASTNode { }
